from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from models.conn import db
from models.models import User
from models.models import Molecule

auth = Blueprint('auth', __name__)

# Route per la home page
@auth.route('/')
def home():
    return redirect(url_for('auth.login'))  # Reindirizza alla login

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()

        if not user or not user.check_password(password):
            # Passa il messaggio di errore direttamente al template
            return render_template('auth/login.html', error_message='Login errato')

        login_user(user)
        if email == 'admin@admin':
            return redirect(url_for('admin.index'))
        return redirect(url_for('auth.profile'))
    
    #qua voglio mettere un codice js è possibile
    return render_template('auth/login.html')


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.login'))

@auth.route('/profile')
@login_required
def profile():
    molecules = Molecule.query.all()
    return render_template('auth/profile.html', name=current_user.username, molecules=molecules)

@auth.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")

        # Validazione dei campi
        if not username or not email or not password:
            flash('All fields are required.', 'error')
            return redirect(url_for('auth.signup'))

        if User.query.filter_by(email=email).first():
            flash('User with this email address already exists.', 'error')
            return redirect(url_for('auth.signup'))

        # Creazione di un nuovo utente
        user = User(username=username, email=email)
        user.set_password(password)  # Salvataggio della password con hash
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()  # Rollback in caso di errore
            flash('An error occurred during registration. Please try again.', 'error')
            return redirect(url_for('auth.signup'))
    
    return render_template('auth/signup.html')
