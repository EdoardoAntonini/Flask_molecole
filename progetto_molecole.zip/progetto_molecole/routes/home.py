from flask import Blueprint, redirect, url_for

home = Blueprint('home', __name__)

@home.route('/')
def home_page():
    return redirect(url_for('auth.login')) 