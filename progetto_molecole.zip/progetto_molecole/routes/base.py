from flask import Blueprint, abort, send_file, request
from rdkit import Chem
from rdkit.Chem import Draw
from io import BytesIO
from models.conn import db
from models.models import Molecule

app = Blueprint('base', __name__)

@app.route('/molecola')
def molecola():
    smiles = request.args.get('smiles')
    molecule_name = request.args.get('name')  # Prendi il nome della molecola dal parametro URL
    show_indices = request.args.get('showIndices') == 'true'
    show_legend = request.args.get('showLegend') == 'true'

    # Se viene passato il nome, cerchiamo la molecola nel database
    if molecule_name:
        molecule_name_lower = molecule_name.lower() 
        molecule = Molecule.query.filter_by(name=molecule_name_lower).first()  
        if molecule:
            smiles = molecule.smiles  
        else:
            abort(400, description=f"Molecola con nome '{molecule_name}' non trovata nella base dati.")

    if not smiles:
        abort(400, description="Nessun SMILES o nome valido fornito.")

    # Creazione dell'immagine della molecola
    mol = Chem.MolFromSmiles(smiles)
    mol = Chem.AddHs(mol)

    if mol is None:
        abort(400, description="SMILES non valido")

    if show_indices:
        for atom in mol.GetAtoms():
            atom.SetProp('atomLabel', str(atom.GetIdx()))

    legend = f'Molecola ({smiles})' if show_legend else ''

    img = Draw.MolToImage(mol, size=(800, 800), kekulize=True, legend=legend)

    img_io = BytesIO()
    img.save(img_io, format='PNG')
    img_io.seek(0)

    return send_file(img_io, mimetype='image/png')
