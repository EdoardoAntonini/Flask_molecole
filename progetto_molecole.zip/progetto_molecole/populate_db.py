import csv
import pandas as pd
from sqlalchemy.exc import IntegrityError
from models.conn import db
from models.models import Molecule
from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///molecole.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    return app

app = create_app()

def insert_molecules_from_csv(csv_path):
    try:
        with app.app_context():
            # Elimina tutte le molecole dalla tabella
            db.session.query(Molecule).delete()
            db.session.commit()
            print("Tutti i record sono stati eliminati dalla tabella molecole.")

            df = pd.read_csv(csv_path)
            print(f"Trovate {len(df)} righe nel file CSV.")

            # Rimuovere duplicati nel CSV
            df = df.drop_duplicates(subset=['smiles'], keep='first')
            print(f"Dopo la rimozione di duplicati nel CSV: {len(df)} righe uniche.")

            for _, row in df.iterrows():
                name = row['name'].strip().lower()
                smiles = row['smiles'].strip()

                # Controlla duplicati nel database
                if Molecule.query.filter_by(smiles=smiles).first() or Molecule.query.filter_by(name=name).first():
                    print(f"Salto duplicato già nel database: {name} ({smiles})")
                    continue

                new_molecule = Molecule(name=name, smiles=smiles)
                db.session.add(new_molecule)

            db.session.commit()
            print("Tutte le molecole sono state aggiunte correttamente!")

    except IntegrityError as e:
        with app.app_context():
            db.session.rollback()
        print(f"Errore di integrità durante l'inserimento: {e}")

    except Exception as e:
        print(f"Errore durante l'inserimento: {e}")

if __name__ == "__main__":
    insert_molecules_from_csv('molecule_data.csv')
