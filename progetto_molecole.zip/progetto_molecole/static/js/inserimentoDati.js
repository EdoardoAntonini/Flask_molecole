document.addEventListener("DOMContentLoaded", function() {
    const moleculeSelect = document.getElementById("moleculeSelect");
    const smilesInput = document.getElementById("smilesInput");

    function toggleFields() {
        if (moleculeSelect.value) {
            smilesInput.disabled = true;  
        } else if (smilesInput.value.trim() !== "") {
            moleculeSelect.disabled = true;  
        } else {
            smilesInput.disabled = false;  
            moleculeSelect.disabled = false;  
        }
    }

    moleculeSelect.addEventListener("change", toggleFields);
    smilesInput.addEventListener("input", toggleFields);

    toggleFields();
});