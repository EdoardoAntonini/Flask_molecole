document.addEventListener("DOMContentLoaded", function () {
    const moleculeSelect = document.getElementById('moleculeSelect');
    const smilesInput = document.getElementById('smilesInput');
    const showIndicesCheckbox = document.getElementById('showIndices');
    const showLegendCheckbox = document.getElementById('showLegend');
    const moleculeImage = document.getElementById('moleculeImage');
    const buttonSave = document.getElementById('save');

    // Funzione per caricare l'immagine della molecola
    function loadMoleculeImage() {
        const smiles = smilesInput.value.trim();
        const moleculeName = moleculeSelect.value;  
        const showIndices = showIndicesCheckbox.checked;
        const showLegend = showLegendCheckbox.checked;

        let url = '/molecola?';

        // Se è stato selezionato un nome nel menu a tendina
        if (moleculeName && moleculeName !== "") {
            url += `name=${encodeURIComponent(moleculeName)}&`;  
        } else if (smiles) {
            url += `smiles=${encodeURIComponent(smiles)}&`;  
        } else {
            return;
        }

        if (showIndices) {
            url += 'showIndices=true&';
        }
        if (showLegend) {
            url += 'showLegend=true&';
        }

        // Chiamata alla route Flask per ottenere l'immagine della molecola
        fetch(url)
            .then(response => response.blob())
            .then(imageBlob => {
                const imageUrl = URL.createObjectURL(imageBlob);
                moleculeImage.src = imageUrl;
                moleculeImage.style.display = 'block';  
                buttonSave.style.display = 'block';
            })
            .catch(error => {
                console.error("Errore nel caricare l'immagine della molecola:", error);
                alert("Errore nel caricare l'immagine della molecola.");
            });
    }

    moleculeSelect.addEventListener('change', loadMoleculeImage);
    smilesInput.addEventListener('input', loadMoleculeImage);
    showIndicesCheckbox.addEventListener('change', loadMoleculeImage);
    showLegendCheckbox.addEventListener('change', loadMoleculeImage);
});
