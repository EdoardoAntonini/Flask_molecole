document.addEventListener("DOMContentLoaded", function () {
    const moleculeImage = document.getElementById('moleculeImage');
    const buttonSave = document.getElementById('save');
    const smilesInput = document.getElementById('smilesInput');
    const moleculeSelect = document.getElementById('moleculeSelect');

    buttonSave.addEventListener('click', function () {
        let fileName = 'molecola';
        const smiles = smilesInput.value.trim();

        if (smiles) {
            fileName += ` - ${smiles}`;
        } else {
            const moleculeName = moleculeSelect.value;
            const selectedOption = moleculeSelect.options[moleculeSelect.selectedIndex];
            const smiles = selectedOption ? selectedOption.getAttribute('data-smiles') : '';
            fileName += ` - ${smiles}`;
        }
        
        fileName += '.png';

        if (moleculeImage.src) {
            const link = document.createElement('a');
            link.href = moleculeImage.src;
            link.download = fileName;

            link.click();
        } else {
            alert("Nessuna immagine da salvare.");
        }
    });
});
